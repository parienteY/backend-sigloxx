<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'pgsql:host=motty.db.elephantsql.com;dbname=hoexggye',
    'username' => 'hoexggye',
    'password' => 'OdLBQrN0MA9MvIBaFL51PzJS9FJGGaCB',
    'charset' => 'utf8',

    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];
